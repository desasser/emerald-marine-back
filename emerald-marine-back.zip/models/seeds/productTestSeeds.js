module.exports = {
    testList: [
        {
            email: 'rachelnelsonschille@gmail.com',
            first: 'Fakey',
            last: 'McFakerson',
            company: 'Fake Inc'
        }
    ]
}
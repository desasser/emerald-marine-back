module.exports = {
    mailingList: [
        {
            email: 'rachelnelsonschille@gmail.com',
            first: 'Fakey',
            last: 'McFakerson',
            company: 'Fake Inc'
        }
    ]
}